<?php

return array(
			'host' => 'localhost',
			'dbname' => 'maxzam',
			'user' => 'root',
			'password' => '',
);