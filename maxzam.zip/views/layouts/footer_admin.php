<hr/>

<center>
    Copyright © 2017 MaxZam | max_dev@inbox.ru
</center>
 
</body>    
</html>