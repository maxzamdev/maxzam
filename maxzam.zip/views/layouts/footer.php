    <div id="templatemo_footer">
        <div class="col col_16">
        	<h4>Разделы сайта</h4>
            <ul class="footer_menu">
            	<li><a href="/">Главная</a></li>
                <li><a href="/catalog">Каталог</a></li>
                <li><a href="/about">О магазине</a></li>
                <li><a href="/contacts">Обратная связь</a></li>
			</ul>  
        </div>
        <div class="col col_16">
        	<h4>Партнеры</h4>
            <ul class="footer_menu">
            	<li><a href="http://www.flashmo.com/">Free Flash Templates</a></li>
                <li><a href="http://www.templatemo.com/">Free CSS Templates</a></li>
                <li><a href="http://www.koflash.com/">Website Gallery</a></li>
                <li><a href="http://www.webdesignmo.com/blog/">Web Design Resources</a></li>
			</ul>  
        </div>
        <div class="col col_16">
        	<h4>Социальные сети</h4>
            <ul class="footer_menu">
            	<li><a href="#">Twitter</a></li>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Youtube</a></li>
                <li><a href="#">LinkedIn</a></li> 
		  </ul>  
        </div>
        <div class="col col_13 no_margin_right">
        	<h4 align="center">О магазине</h4>
                <p>Сайт создан только с целью демонстрации навыков создания интернет магазинов, ничего из заказаного на этой сайте
                вы не получите, цены и картинки взяты с другого интернет магазина. При регистрации можете указывать несуществующее данные.
                При оформлении заказа, тоже можно указывать любые данные. Внимание, при регистрации и оформлении заказов все данные сохраняются в БД.
               </p>
        </div>
        <div class="cleaner h40"></div>
		<center>
			Copyright © 2017 MaxZam | max_dev@inbox.ru
		</center>
    </div> <!-- END of footer -->   
   
</div>

</body>
</html>