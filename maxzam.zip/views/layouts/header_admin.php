<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MaxZam shop</title>
<link rel="stylesheet" type="text/css" href="/template/css/styles.css"/>
</head>
<body id="admin">
    <header>
        <a href="/admin">Admin панель</a>
        <a href="/" style="float: right;">На сайт</a>
    </header>


    
    

   