<?php require_once(ROOT.'/views/layouts/header_admin.php');?>


    <div class="main">
        <p>Здравствуй, админ!</p>
        <ul>
            <li><a href="/admin/product">Управление товарами</a></li>
            <li><a href="/admin/category">Управление категориями</a></li>
            <li><a href="/admin/order">Управление заказами</a></li>
        </ul>
       
    </div>
    

    

<?php require_once(ROOT.'/views/layouts/footer_admin.php');?>